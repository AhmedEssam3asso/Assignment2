from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator


class TaskCreate(BaseModel):
    title: str = Field(min_length=3, max_length=50)
    priority: Literal["low", "medium", "high"]
    description: Optional[str] = "No description"

    @field_validator("title")
    def title_must_start_with_uppercase(cls, value):
        if not value[0].isupper():
            raise ValueError("title must start with an uppercase letter")
        return value


class TaskUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=3, max_length=50)
    priority: Optional[Literal["low", "medium", "high"]] = None
    description: Optional[str] = None

    @field_validator("title")
    def title_must_start_with_uppercase(cls, value):
        if value is not None and not value[0].isupper():
            raise ValueError("title must start with an uppercase letter")
        return value


class TaskResponse(BaseModel):
    task_id: int
    title: str
    priority: str
    description: str
    status: str


if __name__ == "__main__":
    task = TaskCreate(title="Study FastAPI", priority="high")

    print(task.model_dump())
    print(task.model_dump_json())
