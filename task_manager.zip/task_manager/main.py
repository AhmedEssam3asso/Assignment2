from dataclasses import asdict

from fastapi import FastAPI, HTTPException

from models import Task
from schemas import TaskCreate, TaskUpdate, TaskResponse

app = FastAPI()

dataset: dict[int, Task] = {}


@app.post("/tasks")
def create_task(task_data: TaskCreate) -> TaskResponse:
    data = task_data.model_dump()

    task_id = len(dataset) + 1

    new_task = Task(task_id=task_id, **data)
    dataset[task_id] = new_task

    return TaskResponse(**asdict(new_task))


@app.get("/tasks")
def get_tasks() -> list[TaskResponse]:
    result = []
    for task in dataset.values():
        task_dict = asdict(task)
        result.append(TaskResponse(**task_dict))
    return result


@app.delete("/tasks/{task_id}")
def delete_task(task_id: int):
    if task_id not in dataset:
        raise HTTPException(status_code=404, detail="Task not found")

    del dataset[task_id]
    return {"message": f"Task {task_id} deleted successfully"}


@app.patch("/tasks/{task_id}")
def update_task(task_id: int, task_update: TaskUpdate) -> TaskResponse:
    if task_id not in dataset:
        raise HTTPException(status_code=404, detail="Task not found")

    update_data = task_update.model_dump(exclude_unset=True)

    old_task = dataset[task_id]
    old_data = asdict(old_task)

    merged_data = {**old_data, **update_data}

    new_task = Task(**merged_data)
    dataset[task_id] = new_task

    return TaskResponse(**asdict(new_task))
